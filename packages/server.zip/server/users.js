const users = [
    {
      "email": "admin@wideui.com",
      "username": "admin",
      "password": "admin",
      "name": "admin",
      "roleId":1,
      "group_ids": [1, 2, 3, 4, 5]
    },
    {
      "email": "sharath@wideui.com",
      "username": "sharath",
      "password": "sharath",
      "name": "sharath",
      "roleId":2,
      "group_ids": [1, 2, 3, 4]
    },
    {
      "email": "sravanthi@wideui.com",
      "username": "sravanthi",
      "password": "sravanthi",
      "name": "sravanthi",
      "roleId":3,
      "group_ids": [1, 2, 3]
    }
  ]

  module.exports = users