const vessels = [
    {
        "imo": 9991292,
        "name": "Test Vessel",
        "owner": "WinGDShipping",
        "type": "cargo",
        "flag": "France",
        "enginetype": "12x92FF",
        "ecs": "Wice",
        "enginenumber": [
            "8957",
            "8958",
            "common"
        ]
    }
]
module.exports = vessels